Knight & Lansquenet 1.0 Sound Setup
==============================

Copy soundfiles in WAV format here (=subdirectory \sounds).
Rename files for use in Knight & Lansquenet as listed below.

Filename		Trigger event		Sound suggestion
=======================================================
begin_battle.wav	Battle has started		Fanfare
impact.wav	Bullet hits the ground	Explosion
king_dead.wav	A king has died		Outcry or Gong
king_crowned.wav	A king has been crowned	Fanfare
nation_gone.wav	First nation defeated	Gong
betting_office.wav	Betting office opens		Fanfare
end_battle.wav	Battle is over		Fanfare